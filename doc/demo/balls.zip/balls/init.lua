-- load level
scn = elf.LoadScene("balls.pak")

-- set window title and load mouse
elf.SetTitle("BlendELF Balls")
elf.HideMouse(true)

-- set post processing
elf.SetBloom(0.35)

-- create and set a gui
gui = elf.CreateGui()
elf.SetGui(gui)

-- add elf logo to the gui
tex = elf.CreateTextureFromFile("resources/elf.png")
pic = elf.CreatePicture("ELFLogo")
elf.SetPictureTexture(pic, tex)
elf.AddGuiObject(gui, pic)
size = elf.GetGuiObjectSize(pic)
elf.SetGuiObjectPosition(pic, elf.GetWindowWidth()-size.x, 0)

-- add fps display
font = elf.CreateFontFromFile("resources/FreeSans.ttf", 14)
fpslab = elf.CreateLabel("FPSLabel")
elf.SetLabelFont(fpslab, font)
elf.SetLabelText(fpslab, "FPS: ")
elf.SetGuiObjectPosition(fpslab, 10, 10)
elf.AddGuiObject(gui, fpslab)

-- set the ground physics properties
ent = elf.GetEntityByName(scn, "Plane")
elf.SetEntityPhysics(ent, elf.MESH, 0.0)
elf.SetActorRestitution(ent, 0.5)

-- get our ball entity and set its physics properties
ent = elf.GetEntityByName(scn, "Pallo")
elf.SetEntityPhysics(ent, elf.SPHERE, 0.25)
elf.SetActorPosition(ent, 0.0, 0.0, 40.0)
elf.SetActorLinearVelocity(ent, 0.0, 0.0, 5.0)
elf.SetActorRestitution(ent, 0.5)
elf.SetActorSleepThresholds(ent, 0.15, 0.15)

-- get the model and material of the ball entity so that we can generate some more ball entities
mdl = elf.GetEntityModel(ent)
mat = elf.GetEntityMaterial(ent, 0)

-- generate 500 randomly places balls with random velocities!
for i = 0, 499 do
	ent = elf.CreateEntity("Pallo" .. i)
	elf.SetEntityModel(ent, mdl)
	elf.SetEntityMaterial(ent, 0, mat)

	elf.AddEntityToScene(scn, ent)

	elf.SetEntityPhysics(ent, elf.SPHERE, 0.1)
	elf.SetActorPosition(ent, 0.0+math.random(-20, 20), 0.0+math.random(-20, 20), 40.0+math.random(-20, 20))
	elf.SetActorLinearVelocity(ent, math.random(-10, 10), math.random(-10, 10), math.random(-10, 10))
	elf.SetActorAngularVelocity(ent, math.random(-10, 10), math.random(-10, 10), math.random(-10, 10))
	elf.SetActorDamping(ent, 0.02, 0.25)
	elf.SetActorRestitution(ent, 0.5);
	elf.SetActorSleepThresholds(ent, 0.15, 0.15)
end

-- store some helper variables for interpolating camera rotation with the mouse
imfx = 0.0
imfy = 0.0

-- store a handle to the current camere so that we can move it
cam = elf.GetSceneActiveCamera(scn)

-- main loop
while elf.Run() == true do
	-- update the fps display
	elf.SetLabelText(fpslab, "FPS: " .. elf.GetFps())
	
	-- move the camera with WSAD
	if elf.GetKeyState(elf.KEY_W) ~= elf.UP then elf.MoveActorLocal(cam, 0.0, 0.0, -12.0) end
	if elf.GetKeyState(elf.KEY_S) ~= elf.UP then elf.MoveActorLocal(cam, 0.0, 0.0, 12.0) end
	if elf.GetKeyState(elf.KEY_A) ~= elf.UP then elf.MoveActorLocal(cam, -12.0, 0.0, 0.0) end
	if elf.GetKeyState(elf.KEY_D) ~= elf.UP then elf.MoveActorLocal(cam, 12.0, 0.0, 0.0) end

	-- rotate the camera with the mouse and perform a bit of interpolation for softer movement
	mf = elf.GetMouseForce()
	imfx = (imfx*3.0+mf.x)/4.0
	imfy = (imfy*3.0+mf.y)/4.0
	elf.RotateActorLocal(cam, -imfy*10.0, 0.0, 0.0)
	elf.RotateActor(cam, 0.0, 0.0, -imfx*10.0)
	
	-- take a screen shot if the user presses 'X'
	if elf.GetKeyState(elf.KEY_X) == elf.PRESSED then print("screen shot!"); elf.SaveScreenShot("screenshot.png") end

	-- exit with ESC
	if elf.GetKeyState(elf.KEY_ESC) == elf.PRESSED then elf.Quit() end
end

