
-- load level, set window title and hide mouse
scn = elf.LoadScene("level1.pak")
elf.SetTitle("BlendELF Demo 1")
elf.HideMouse(true)

-- set some bloom and declare mouse rotation interpolation values
elf.SetBloom(0.6)
imfx = 0.0
imfy = 0.0

-- create and set a gui
gui = elf.CreateGui()
elf.SetGui(gui)

-- add the elf logo to the gui
tex = elf.CreateTextureFromFile("resources/elf.png")
pic = elf.CreatePicture("ELFLogo")
elf.SetPictureTexture(pic, tex)
elf.AddGuiObject(gui, pic)
size = elf.GetGuiObjectSize(pic)
elf.SetGuiObjectPosition(pic, elf.GetWindowWidth()-size.x, 0)

-- add fps display
font = elf.CreateFontFromFile("resources/FreeSans.ttf", 14)
fpslab = elf.CreateLabel("FPSLabel")
elf.SetLabelFont(fpslab, font)
elf.SetLabelText(fpslab, "FPS: ")
elf.SetGuiObjectPosition(fpslab, 10, 10)
elf.AddGuiObject(gui, fpslab)

-- get the camera for camera movement
cam = elf.GetSceneActiveCamera(scn)

while elf.Run() == true do
	-- update the fps display
	elf.SetLabelText(fpslab, "FPS: " .. elf.GetFps())

	-- move the camera WSAD
	if elf.GetKeyState(elf.KEY_W) ~= elf.UP then elf.MoveActorLocal(cam, 0.0, 0.0, -12.0) end
	if elf.GetKeyState(elf.KEY_S) ~= elf.UP then elf.MoveActorLocal(cam, 0.0, 0.0, 12.0) end
	if elf.GetKeyState(elf.KEY_A) ~= elf.UP then elf.MoveActorLocal(cam, -12.0, 0.0, 0.0) end
	if elf.GetKeyState(elf.KEY_D) ~= elf.UP then elf.MoveActorLocal(cam, 12.0, 0.0, 0.0) end

	-- rotate the camera
	mf = elf.GetMouseForce()
	imfx = (imfx*3.0+mf.x)/4.0
	imfy = (imfy*3.0+mf.y)/4.0
	elf.RotateActorLocal(cam, -imfy*10.0, 0.0, 0.0)
	elf.RotateActor(cam, 0.0, 0.0, -imfx*10.0)
	
	-- take a screen shot with key X
	if elf.GetKeyState(elf.KEY_X) == elf.PRESSED then elf.SaveScreenShot("screenshot.jpg") end
	-- exit with key ESC
	if elf.GetKeyState(elf.KEY_ESC) == elf.PRESSED then elf.Quit() end
end

